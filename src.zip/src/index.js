// WAC-QuizBot - index.js

const {
    startWorldPassScheduler,
} = require("./services/worldPass/worldPassScheduler.js")
const {
    startWorldPassRewardWorker,
} = require("./services/worldPass/worldPassReward");
// ==============================
// USERS WHO CAN ACCESS COMMANDS
// ==============================
const COMMAND_ACCESS =
    require("./services/COMMAND_ACCESS.js").COMMAND_ACCESS;
// ==============================
// BOSS MODE
// ==============================
const {
    handleBossCommand,
    handleBossButton,
} = require("../src/services/boss/boss.js");
// ==============================
// BLOCKED QUIZ USERS
// ==============================
const BLOCKED_QUIZ_USERS = new Set([]);
const {
    handleBanCommand,
    isQuizBanned,
} = require("./services/quizBan");
const {
    handleKahootCommand,
    handleKahootInteraction,
} = require("./services/kahoot/kahoot");
const {
    handlePaymentButton,
} = require("./services/paymentService");

require("dotenv").config();
const { Redis } = require("@upstash/redis");

const redis = new Redis({
    url: process.env.UPSTASH_REDIS_REST_URL,
    token: process.env.UPSTASH_REDIS_REST_TOKEN,
});
const {
    LEADERBOARD_BUTTON_ID,
    handleLeaderboardButton,
} = require("./services/leaderboard/leaderboard");
// ==========================================
// QUIZ BAN RESPONSE EMBED
// ==========================================
function createQuizBanNoticeEmbed(ban, eventLabel = "quiz") {
    const hours = Math.floor((ban.ttl || 0) / 3600);
    const minutes = Math.floor(((ban.ttl || 0) % 3600) / 60);
    const seconds = (ban.ttl || 0) % 60;

    return new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle("🚫 Participation Restricted")
        .setDescription(
            `You are temporarily blocked from participating in the **${eventLabel}**.`
        )
        .addFields(
            {
                name: "⏳ Time Remaining",
                value: `**${hours}h ${minutes}m ${seconds}s**`,
                inline: true,
            },
            {
                name: "📝 Ban Reason",
                value: ban.reason || "No reason provided.",
                inline: false,
            }
        )
        .setFooter({ text: "World Adventure Club • Quiz Moderation" })
        .setTimestamp();
}
const http = require("http");

const PORT = process.env.PORT || 3000;

http.createServer((req, res) => {
    res.writeHead(200);
    res.end("WAC-QuizBot is running");
}).listen(PORT, () => {
    console.log(`🌐 HTTP server running on port ${PORT}`);
});
const {
    handleWeeklyCommand,
    handleWeeklyButton,
    startWeeklyScheduler,
} = require("./services/weekly/weekly.js");
// ==============================
// UTILITIES FUNCTION IMPORTS
// ==============================

const {
    handleResolve,
} = require("./services/resolve");

const {
    dailyeventCooldownCommand,
    handleDailyEventCooldown,
} = require("./services/dailyEventCooldownAdmin");
const {
    treasureCooldownCommand,
    handleTreasureCooldown,
} = require("./services/treasureCooldownAdmin");
const {
    handleCountUsernames,
    handleCountUsernamesCopy,
} = require("./services/countUsernames");
const {
    startTreasureChestEvent,
    handleTreasureChestButton,
} = require("./services/treasureChestEvent");
const {
    clearAllTreasureCooldowns,
} = require("./services/treasureChestEventredis");
const {
    Client,
    GatewayIntentBits,
    Events,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    MessageFlags
} = require("discord.js");

const { generateQuiz } = require("./services/ai");
const {
    handleWorldPassCommand,
    handleWorldPassComponent,
} = require("./src/services/worldPass/worldPassCommand");
const {
    startDailyQuiz,
    handleDailyQuizButton,
    handleDailyQuizCountrySelect,
    handleDailyQuizAnswer,
    killDailyQuiz,
    killDailyQuizHistory,
} = require("./services/dailyQuiz");
const {
    startMysteryEvent,
    killMysteryEvent,
    handleMysteryReveal,
    handleMysteryAnswer,

    listAllMysteryUserCooldowns,
    listMysteryCooldown,
    setMysteryUserCooldown,
    checkMysteryCooldown,
    clearMysteryUserCooldown,
    clearAllMysteryUserCooldowns,
} = require("./services/mysteryDailyEvent");

const {
    handleStatsCommand,
    handleStatsButton,
} = require("./services/stats");
// ==============================
// CLIENT
// ==============================

const client = new Client({
    intents: [GatewayIntentBits.Guilds],
});

// ==============================
// QUIZ SETTINGS
// ==============================

const activeQuizzes = new Map();
const {
    initializeWorldPassPools,
    startWorldPassPoolManager,
} = require("./src/services/worldPass/worldPassPool");
// 30 seconds
const QUIZ_DURATION = 20_000;

const MAX_WINNERS = 5;

// ==============================
// BOT READY
// ==============================

client.once(Events.ClientReady, (client) => {
    console.log(`✅ ${client.user.tag} is online!`);
    startWeeklyScheduler(client);
    startWorldPassScheduler();
    startWorldPassRewardWorker(client);
});


// ==============================
// INTERACTIONS
// ==============================

client.on(Events.InteractionCreate, async (interaction) => {

    // ==========================================
    // /quiz + /dailyquiz COMMAND
    // ==========================================

    if (interaction.isChatInputCommand()) {

        // ==========================================
        // WEEKLY WORLD QUIZ — ACKNOWLEDGE IMMEDIATELY
        // This must run before generic command routing/access checks.
        // ==========================================
        if (interaction.commandName === "weekly") {
            const action = interaction.options.getString("action", true);
            const weeklyAdmins = COMMAND_ACCESS.weekly || COMMAND_ACCESS.dailyevent || [];
            const isAuthorizedStart = action === "start" &&
                weeklyAdmins.map(String).includes(String(interaction.user.id));

            try {
                await interaction.deferReply(
                    isAuthorizedStart ? {} : { flags: MessageFlags.Ephemeral }
                );
            } catch (ackError) {
                console.error("[weekly] Could not acknowledge command:", ackError);
                return;
            }

            try {
                await handleWeeklyCommand(interaction, client);
            } catch (error) {
                console.error("[weekly] Command failed:", error);

                const response = {
                    content: "❌ The weekly command failed. Please try again.",
                    embeds: [],
                    components: [],
                };

                try {
                    if (interaction.deferred) {
                        await interaction.editReply(response);
                    } else if (interaction.replied) {
                        await interaction.followUp({
                            ...response,
                            flags: MessageFlags.Ephemeral,
                        });
                    } else {
                        await interaction.reply({
                            ...response,
                            flags: MessageFlags.Ephemeral,
                        });
                    }
                } catch (responseError) {
                    console.error("[weekly] Could not send command error:", responseError);
                }
            }

            return;
        }

        // ==========================================
        // COMMAND ACCESS CONTROL
        // ==========================================

        let accessKey = interaction.commandName;

        if (interaction.commandName === "kill") {

            const subcommand =
                interaction.options.getSubcommand();

            accessKey = `kill:${subcommand}`;
        }

        if (interaction.commandName === "mysteryevent") {
            const subcommand =
                interaction.options.getSubcommand();

            const subcommandGroup =
                interaction.options.getSubcommandGroup(false);

            if (subcommandGroup === "cooldown") {
                accessKey = "mysteryevent:cooldown";
            } else if (subcommand === "kill") {
                accessKey = "mysteryevent:kill";
            } else if (subcommand === "start") {
                accessKey = "mysteryevent";
            }
        }

        const allowedUsers =
            COMMAND_ACCESS[accessKey] || [];

        if (!allowedUsers.includes(interaction.user.id)) {

            await interaction.reply({
                content:
                    "❌ You are not authorized to use this command.",
                flags: MessageFlags.Ephemeral,
            });

            return;
        }
        // ==========================================
        // WORLD PASS CHALLENGE CONTROL
        // ==========================================
        try {
            if (
                interaction.isChatInputCommand() &&
                interaction.commandName === "pass-challenge"
            ) {
                await handleWorldPassCommand(interaction);
                return;
            }

            if (
                interaction.isButton() ||
                interaction.isStringSelectMenu()
            ) {
                const handled = await handleWorldPassComponent(interaction);
                if (handled) return;
            }
        } catch (error) {
            console.error("❌ WORLD PASS INTERACTION ERROR:", error);
        }
        // ==========================================
        // WORLD BOSS MODE
        // ==========================================
        if (interaction.commandName === "boss") {
            try {
                const action = interaction.options.getString("action", true);

                // Same authorization convention as Weekly Quiz.
                const bossAdmins =
                    COMMAND_ACCESS.weekly ||
                    COMMAND_ACCESS.dailyevent ||
                    [];

                const isAdmin = bossAdmins
                    .map(String)
                    .includes(String(interaction.user.id));

                const adminActions = [
                    "start",
                    "end",
                    "reset",
                    "participants",
                ];

                if (adminActions.includes(action) && !isAdmin) {
                    return interaction.reply({
                        content: "❌ You are not authorized to manage Boss Mode.",
                        flags: MessageFlags.Ephemeral,
                    });
                }

                await handleBossCommand(interaction, client);

            } catch (error) {
                console.error("[boss] Command failed:", error);

                const response = {
                    content: "❌ Boss Mode command failed.",
                    embeds: [],
                    components: [],
                };

                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply(response).catch(() => { });
                } else {
                    await interaction.reply({
                        ...response,
                        flags: MessageFlags.Ephemeral,
                    }).catch(() => { });
                }
            }

            return;
        }


        // ==========================================
        // /ping COMMAND
        // ==========================================

        if (interaction.isChatInputCommand() && interaction.commandName === "ping") {
            const start = Date.now();

            await interaction.deferReply();

            const responseTime = Date.now() - start;
            const apiLatency = Math.round(client.ws.ping);

            const { EmbedBuilder } = require("discord.js");

            const embed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle("🏓 Pong!")
                .addFields(
                    {
                        name: "⚡ Response Time",
                        value: `\`${responseTime}ms\``,
                        inline: true
                    },
                    {
                        name: "📡 Gateway Latency",
                        value: `\`${apiLatency}ms\``,
                        inline: true
                    }
                )
                .setFooter({
                    text: "World Adventure Club"
                })
                .setTimestamp();

            await interaction.editReply({
                embeds: [embed]
            });

            return;
        }


        // ==========================================
        // /Moderation COMMAND
        // ==========================================
        if (interaction.commandName === "ban") {
            await handleBanCommand(interaction, redis);
            return;
        }
        // ==========================================
        // /stats
        // ==========================================

        if (interaction.commandName === "stats") {
            await handleStatsCommand(interaction);
            return;
        }
        // ==========================================
        // /mysteryevent
        // ==========================================

        if (
            interaction.commandName === "mysteryevent"
        ) {
            const subcommand =
                interaction.options.getSubcommand();

            const subcommandGroup =
                interaction.options.getSubcommandGroup(false);

            // ==========================================
            // /mysteryevent start
            // ==========================================

            if (
                !subcommandGroup &&
                subcommand === "start"
            ) {
                try {
                    await interaction.deferReply();

                    const result =
                        await startMysteryEvent(
                            interaction
                        );

                    if (!result.success && result.reason === "already_active") {
                        await interaction.editReply({
                            content:
                                "⚠️ A Mystery Event is already active.",
                        });

                        return;
                    }

                } catch (error) {
                    console.error(
                        "❌ Mystery Event start failed:",
                        error
                    );

                    if (interaction.deferred || interaction.replied) {
                        await interaction.editReply({
                            content:
                                "❌ Failed to start the Mystery Event.",
                        });
                    }
                }

                return;
            }

            // ==========================================
            // /mysteryevent kill
            // ==========================================

            if (
                !subcommandGroup &&
                subcommand === "kill"
            ) {
                try {
                    await interaction.deferReply({
                        flags: MessageFlags.Ephemeral,
                    });

                    const result =
                        await killMysteryEvent();

                    if (!result.success) {
                        await interaction.editReply({
                            content:
                                "ℹ️ There is no active Mystery Event to terminate.",
                        });

                        return;
                    }

                    await interaction.editReply({
                        content:
                            "🛑 **Mystery Event forcefully terminated.**\n\n" +
                            "📦 Question pool and question history were preserved.",
                    });

                } catch (error) {
                    console.error(
                        "❌ Mystery Event kill failed:",
                        error
                    );

                    if (
                        interaction.deferred ||
                        interaction.replied
                    ) {
                        await interaction.editReply({
                            content:
                                "❌ Failed to terminate the Mystery Event.",
                        });
                    }
                }

                return;
            }

            // ==========================================
            // /mysteryevent cooldown
            // ==========================================

            if (
                subcommandGroup === "cooldown"
            ) {
                try {
                    await interaction.deferReply({
                        flags: MessageFlags.Ephemeral,
                    });

                    const user =
                        interaction.options.getUser(
                            "user"
                        );

                    // ----------------------------------
                    // LIST ALL ACTIVE COOLDOWNS
                    // ----------------------------------

                    if (subcommand === "list") {
                        const cooldowns =
                            await listAllMysteryUserCooldowns();

                        if (!cooldowns.length) {
                            await interaction.editReply({
                                content:
                                    "🔮 **MYSTERY ACTIVE COOLDOWNS**\
\
" +
                                    "No users currently have an active Mystery cooldown.",
                            });

                            return;
                        }

                        const formatTime = (seconds) => {
                            const total = Math.max(0, Number(seconds));
                            const hours = Math.floor(total / 3600);
                            const minutes = Math.floor((total % 3600) / 60);
                            const secs = total % 60;

                            if (hours > 0) {
                                return `${hours}h ${minutes}m ${secs}s`;
                            }

                            if (minutes > 0) {
                                return `${minutes}m ${secs}s`;
                            }

                            return `${secs}s`;
                        };

                        const lines = [
                            "🔮 **DAILY MYSTERY EVENT ACTIVE COOLDOWNS**\n\n",
                            "",
                        ];

                        for (const cooldown of cooldowns) {
                            lines.push(
                                `👤 <@${cooldown.userId}> - `,
                                `⏳**${formatTime(cooldown.ttl)}**\n`,
                                ""
                            );
                        }

                        lines.push(

                            `\n\n👥 **Active Cooldowns: ${cooldowns.length}**`
                        );

                        // Discord messages are limited to 2000 characters.
                        const chunks = [];
                        let current = "";

                        for (const line of lines) {
                            const next = current
                                ? `${current}\
${line}`
                                : line;

                            if (next.length > 1900) {
                                chunks.push(current);
                                current = line;
                            } else {
                                current = next;
                            }
                        }

                        if (current) {
                            chunks.push(current);
                        }

                        await interaction.editReply({
                            content: chunks.shift(),
                        });

                        for (const chunk of chunks) {
                            await interaction.followUp({
                                content: chunk,
                                flags: MessageFlags.Ephemeral,
                            });
                        }

                        return;
                    }

                    // ----------------------------------
                    // CHECK ONE USER
                    // ----------------------------------

                    if (subcommand === "check") {
                        const cooldown =
                            await checkMysteryCooldown(
                                user.id
                            );

                        if (Number(cooldown) <= 0) {
                            await interaction.editReply({
                                content:
                                    `🔮 <@${user.id}> has **no active Mystery cooldown**.`,
                            });

                            return;
                        }

                        const expiresAt =
                            Date.now() +
                            Number(cooldown) * 1000;

                        await interaction.editReply({
                            content:
                                `🔮 **Mystery Cooldown Check**\
\
` +
                                `👤 User: <@${user.id}>\
` +
                                `⏳ Remaining: **${cooldown}s**\
` +
                                `🕐 Expires: <t:${Math.floor(expiresAt / 1000)}:F>`,
                        });

                        return;
                    }

                    // ----------------------------------
                    // SET ONE USER
                    // ----------------------------------

                    if (subcommand === "set") {
                        const hours =
                            interaction.options.getNumber(
                                "hours"
                            );

                        const result =
                            await setMysteryUserCooldown(
                                user.id,
                                hours
                            );

                        const expiresAt =
                            Date.now() +
                            Number(result.cooldownSeconds) * 1000;

                        await interaction.editReply({
                            content:
                                `🔮 **Mystery Cooldown Set**\
\
` +
                                `👤 User: <@${user.id}>\
` +
                                `⏳ Duration: **${hours} hour(s)**\
` +
                                `🕐 Expires: <t:${Math.floor(expiresAt / 1000)}:F>`,
                        });

                        return;
                    }

                    // ----------------------------------
                    // CLEAR ONE / ALL
                    // ----------------------------------

                    if (subcommand === "clear") {
                        const clearAll =
                            interaction.options.getBoolean(
                                "all"
                            ) || false;

                        if (clearAll) {
                            const deleted =
                                await clearAllMysteryUserCooldowns();

                            await interaction.editReply({
                                content:
                                    `🧹 **MYSTERY COOLDOWNS CLEARED**\
\
` +
                                    `🗑️ Removed **${deleted}** cooldown(s).`,
                            });

                            return;
                        }

                        if (!user) {
                            await interaction.editReply({
                                content:
                                    "❌ Select a user or enable **all**.",
                            });

                            return;
                        }

                        const deleted =
                            await clearMysteryUserCooldown(
                                user.id
                            );

                        await interaction.editReply({
                            content:
                                deleted
                                    ? `🧹 Cleared Mystery cooldown for <@${user.id}>.`
                                    : `ℹ️ <@${user.id}> did not have an active Mystery cooldown.`,
                        });

                        return;
                    }

                } catch (error) {
                    console.error(
                        "❌ Mystery cooldown command failed:",
                        error
                    );

                    await interaction.editReply({
                        content:
                            "❌ Failed to process the Mystery cooldown command.",
                    });
                }

                return;
            }

            // ==========================================
            // /mysteryevent
            // ==========================================

            if (
                !subcommandGroup &&
                !subcommand
            ) {
                try {
                    await interaction.deferReply({
                        flags: MessageFlags.Ephemeral,
                    });

                    const result =
                        await startMysteryEvent({
                            channel:
                                interaction.channel,
                        });

                    if (
                        !result.success &&
                        result.reason === "already_active"
                    ) {
                        await interaction.editReply({
                            content:
                                "⚠️ A Mystery Event is already active.",
                        });

                        return;
                    }

                    await interaction.editReply({
                        content:
                            "🔮 **Mystery Event activated!**\n\n" +
                            "The Daily World Mystery Drop is now live.",
                    });

                } catch (error) {
                    console.error(
                        "❌ Mystery Event start failed:",
                        error
                    );

                    await interaction.editReply({
                        content:
                            "❌ Failed to start the Mystery Event.",
                    });
                }

                return;
            }
        }

        // ==========================================
        // /testdm @username COMMAND
        // ==========================================  

        if (interaction.commandName === "testdm") {
            try {
                const user = interaction.options.getUser("user");

                await user.send(
                    `🧪 Test DM\nTime: ${new Date().toLocaleTimeString()}`
                );

                await interaction.reply({
                    content: `✅ DM sent to ${user.tag}`,
                    flags: MessageFlags.Ephemeral,
                });
            } catch (error) {
                console.error("❌ DM failed:", error);

                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({
                        content: `❌ DM failed: ${error.message}`,
                        flags: MessageFlags.Ephemeral,
                    });
                }
            }

            return;
        }


        // ==========================================
        // /dailyeventcooldown COMMAND
        // ==========================================     
        if (interaction.commandName === "dailyeventcooldown") {
            try {
                await interaction.deferReply({
                    flags: MessageFlags.Ephemeral,
                });

                await handleDailyEventCooldown(interaction);
            } catch (error) {
                console.error(
                    "❌ Daily Event Cooldown command failed:",
                    error?.message || error
                );

                try {
                    if (interaction.deferred || interaction.replied) {
                        await interaction.editReply({
                            content:
                                "❌ Failed to retrieve Daily Event cooldowns.",
                        });
                    }
                } catch (replyError) {
                    console.error(
                        "❌ Could not send cooldown error:",
                        replyError?.message || replyError
                    );
                }
            }

            return;
        }
        // ==========================================
        // /treasurecooldown COMMAND
        // ==========================================       
        if (interaction.commandName === "treasurecooldown") {
            try {
                await interaction.deferReply({
                    flags: MessageFlags.Ephemeral,
                });

                await handleTreasureCooldown(interaction);
            } catch (error) {
                console.error(
                    "❌ Treasure Cooldown command failed:",
                    error?.message || error
                );

                try {
                    if (interaction.deferred || interaction.replied) {
                        await interaction.editReply({
                            content:
                                "❌ Failed to process Treasure Cooldown command.",
                        });
                    }
                } catch (replyError) {
                    console.error(
                        "❌ Could not send Treasure Cooldown error:",
                        replyError?.message || replyError
                    );
                }
            }

            return;
        }
        // ==========================================
        // /kill treasure COMMAND
        // ==========================================
        if (
            interaction.commandName === "kill" &&
            interaction.options.getSubcommand() === "treasure"
        ) {
            try {
                const deleted =
                    await clearAllTreasureCooldowns();

                await interaction.reply({
                    content:
                        `🧹 **TREASURE HISTORY CLEARED**\n\n` +
                        `🗑️ Removed **${deleted}** treasure cooldown(s).\n` +
                        `🏝️ Everyone can use \`/treasure\` again.`,
                });
            } catch (error) {
                console.error(
                    "❌ Failed to clear treasure history:",
                    error
                );

                await interaction.reply({
                    content:
                        "❌ Failed to clear Treasure history.",
                    flags: MessageFlags.Ephemeral,
                });
            }

            return;
        }
        // ==========================================
        // /treasure COMMAND
        // ==========================================
        if (interaction.commandName === "treasure") {
            await startTreasureChestEvent(interaction);
            return;
        }

        // ==========================================
        // /resolve
        // ==========================================

        if (interaction.commandName === "resolve") {

            await handleResolve(interaction);

            return;
        }

        // ==========================================
        // /countusernames
        // ==========================================

        if (interaction.commandName === "countusernames") {

            await handleCountUsernames(interaction);

            return;
        }

        // ==========================================
        // /kill
        // ==========================================

        if (interaction.commandName === "kill") {

            const subcommand =
                interaction.options.getSubcommand();

            // ==========================================
            // /kill history
            // ==========================================

            if (subcommand === "history") {

                console.log("🔥 /kill history reached");

                await interaction.deferReply({
                    flags: MessageFlags.Ephemeral,
                });

                const deleted =
                    await killDailyQuizHistory();

                if (deleted === false) {

                    console.log(
                        "🔥 /kill history reached deleted false"
                    );

                    await interaction.editReply({
                        content:
                            "❌ Failed to clear Daily Quiz participation history.",
                    });

                    return;
                }

                await interaction.editReply({
                    content:
                        `✅ Cleared **${deleted}** Daily Quiz participation record(s).\n\n` +
                        `Everyone can participate again.`,
                });

                console.log(
                    "🔥 /kill history reached deleted true"
                );

                return;
            }

            // ==========================================
            // /kill dailyquiz
            // ==========================================

            if (
                interaction.options.getSubcommand() ===
                "dailyevent"
            ) {


                // Acknowledge immediately so Discord does not expire
                // the interaction while killDailyQuiz() is working.
                await interaction.deferReply({
                    flags: MessageFlags.Ephemeral,
                });

                const killed =
                    await killDailyQuiz();

                if (!killed) {

                    await interaction.editReply({
                        content:
                            "ℹ️ There is no active Daily Quiz to terminate.",
                    });

                    return;
                }

                await interaction.editReply({
                    content:
                        "🛑 **Daily Quiz forcefully terminated.** You can start a new `/dailyquiz` now.",
                });

                return;
            }
        }

        // ==========================================
        // /dailyquiz
        // ==========================================

        if (
            interaction.commandName ===
            "dailyevent"
        ) {

            await startDailyQuiz(
                interaction
            );

            return;
        }

        // ==========================================
        // /quiz
        // ==========================================



        if (
            interaction.commandName !==
            "quiz"
        ) {
            return;
        }

        // ==========================================
        // NORMAL /QUIZ
        // ==========================================

        const region =
            interaction.options.getString(
                "region"
            );

        const topic =
            interaction.options.getString(
                "topic"
            );

        const difficulty =
            interaction.options.getString(
                "difficulty"
            );
        const reset =
            interaction.options.getBoolean("reset") || false;

        await interaction.deferReply();

        try {

            // ==========================================
            // GENERATE QUESTION
            // ==========================================

            const quiz =
                await generateQuiz(
                    region,
                    topic,
                    difficulty
                );


            // Reset counter when reset:true
            if (reset) {
                await redis.set(
                    "wac:stats:questions_asked",
                    0
                );
            }

            // Get next question number
            const questionNumber =
                await redis.incr(
                    "wac:stats:questions_asked"
                );




            const quizId =
                interaction.id;

            const startedAt =
                Date.now();

            const endsAt =
                startedAt +
                QUIZ_DURATION;

            const endUnix =
                Math.floor(
                    endsAt / 1000
                );

            // ==========================================
            // STORE QUIZ
            // ==========================================

            activeQuizzes.set(
                quizId,
                {
                    question:
                        quiz.question,
                    questionNumber,

                    options:
                        quiz.options,

                    correctAnswer:
                        quiz.correctAnswer,

                    explanation:
                        quiz.explanation,

                    answers:
                        new Map(),

                    startedAt,
                    endsAt,

                    interaction,
                }
            );

            // ==========================================
            // QUIZ EMBED
            // ==========================================

            const embed =
                new EmbedBuilder()
                    .setColor(
                        0x5865F2
                    )
                    .setAuthor({
                        name:
                            "🌍 WORLD ADVENTURE CLUB QUIZ",
                    })
                    .setDescription(
                        `### Question No. ${questionNumber}\n\n` +
                        `### ${quiz.question}\n\n` +
                        `⏱️ **Time Remaining:** <t:${endUnix}:R>`
                    )
                    .setFooter({
                        text:
                            "WAC • World Adventure Club",
                    });

            // ==========================================
            // ANSWER BUTTONS
            // ==========================================

            const buttons =
                quiz.options.map(
                    (option, index) => {

                        return new ButtonBuilder()
                            .setCustomId(
                                `quiz_${quizId}_${index}`
                            )
                            .setLabel(
                                option
                            )
                            .setStyle(
                                ButtonStyle.Primary
                            );
                    }
                );

            // ==========================================
            // 2 × 2 LAYOUT
            // ==========================================

            const row1 =
                new ActionRowBuilder()
                    .addComponents(
                        buttons[0],
                        buttons[1]
                    );

            const row2 =
                new ActionRowBuilder()
                    .addComponents(
                        buttons[2],
                        buttons[3]
                    );

            // ==========================================
            // SEND QUIZ
            // ==========================================

            await interaction.editReply({
                embeds: [
                    embed,
                ],

                components: [
                    row1,
                    row2,
                ],
            });

            // ==========================================
            // START TIMESTAMP UPDATER
            // ==========================================

            startTimestampUpdater(
                quizId
            );

            // ==========================================
            // FINISH AFTER 30 SECONDS
            // ==========================================

            setTimeout(
                () =>
                    finishQuiz(
                        quizId
                    ),
                QUIZ_DURATION
            );

        } catch (error) {

            console.error(
                "Quiz generation failed:",
                error
            );

            try {

                await interaction.editReply({
                    content:
                        "❌ I couldn't generate the quiz question. Please try again.",

                    embeds: [],

                    components: [],
                });

            } catch (replyError) {

                console.error(
                    "Failed to send error message:",
                    replyError
                );
            }
        }

        return;
    }

    // ==========================================
    // DAILY QUIZ MODAL
    // ==========================================

    if (interaction.isModalSubmit()) {

        if (
            interaction.customId.startsWith(
                "dailyquiz_submit_"
            )
        ) {

            await handleDailyQuizAnswer(
                interaction
            );

            return;
        }
    }

    // ==========================================
    // DAILY QUIZ COUNTRY DROPDOWN
    // ==========================================

    if (interaction.isStringSelectMenu()) {

        if (
            interaction.customId ===
            "dailyquiz_country"
        ) {

            await handleDailyQuizCountrySelect(
                interaction
            );

            return;
        }
    }

    // ==========================================
    // BUTTON INTERACTION
    // ==========================================

    if (interaction.isButton() ||
        interaction.isStringSelectMenu() ||
        interaction.isModalSubmit()) {
        // ==========================================
        // WEEKLY WORLD QUIZ BUTTONS
        // ==========================================

        if (
            interaction.isButton() &&
            interaction.customId?.startsWith("weekly:")
        ) {
            try {
                await handleWeeklyButton(interaction, client);
            } catch (error) {
                console.error("[weekly] Button failed:", error);

                if (!interaction.replied && !interaction.deferred) {
                    await interaction.reply({
                        content: "❌ Something went wrong. Please try again.",
                        flags: MessageFlags.Ephemeral,
                    }).catch(console.error);
                }
            }

            return;
        }
        // ==========================================
        // BOSS MODE BUTTONS
        // ==========================================
        if (
            interaction.isButton() &&
            interaction.customId.startsWith("boss:")
        ) {
            try {
                await handleBossButton(interaction);
            } catch (error) {
                console.error("[boss] Button failed:", error);

                const response = {
                    content: "❌ Could not process this Boss Mode interaction.",
                    embeds: [],
                    components: [],
                };

                if (interaction.deferred || interaction.replied) {
                    await interaction.followUp({
                        ...response,
                        flags: MessageFlags.Ephemeral,
                    }).catch(() => { });
                } else {
                    await interaction.reply({
                        ...response,
                        flags: MessageFlags.Ephemeral,
                    }).catch(() => { });
                }
            }

            return;
        }
        // ==========================================
        // KAHOOT BUTTON INTERACTION
        // ==========================================
        const isKahootInteraction =
            interaction.customId?.startsWith("kahoot:");

        if (isKahootInteraction) {
            await handleKahootInteraction(interaction);
            return;
        }

        // ------------------------------------------
        // MYSTERY EVENT
        // ------------------------------------------

        if (
            interaction.customId.startsWith("stats_")
        ) {
            await handleStatsButton(
                interaction
            );

            return;
        }
        // ------------------------------------------
        // MORA LEADERBOARD BUTTON
        // ------------------------------------------

        if (
            interaction.isButton() &&
            interaction.customId === LEADERBOARD_BUTTON_ID
        ) {
            await handleLeaderboardButton(interaction);
            return;
        }
        if (
            interaction.customId ===
            "mysteryevent_reveal"
        ) {
            const ban = await isQuizBanned(redis, interaction.user.id);
            if (ban.banned) {
                await interaction.reply({
                    embeds: [createQuizBanNoticeEmbed(ban, "Mystery Event")],
                    flags: MessageFlags.Ephemeral,
                });
                return;
            }

            await handleMysteryReveal(interaction);
            return;
        }

        if (
            interaction.customId.startsWith(
                "mysteryevent_answer:"
            )
        ) {
            const ban = await isQuizBanned(redis, interaction.user.id);
            if (ban.banned) {
                await interaction.reply({
                    embeds: [createQuizBanNoticeEmbed(ban, "Mystery Event")],
                    flags: MessageFlags.Ephemeral,
                });
                return;
            }

            await handleMysteryAnswer(interaction);
            return;
        }
        // ------------------------------------------
        // Payment BUTTON
        // ------------------------------------------        
        if (
            interaction.customId.startsWith("payment_paid_")
        ) {
            await handlePaymentButton(interaction);
            return;
        }
        // ------------------------------------------
        // TREASURE CHEST BUTTON
        // ------------------------------------------
        if (interaction.customId.startsWith("treasure_open_")
        ) {
            await handleTreasureChestButton(interaction);
            return;
        }
        // ------------------------------------------
        // COPY USERNAMES BUTTON
        // ------------------------------------------

        if (
            interaction.customId ===
            "countusernames_copy"
        ) {

            await handleCountUsernamesCopy(
                interaction
            );

            return;
        }

        // ------------------------------------------
        // DAILY QUIZ
        // ------------------------------------------
        if (
            interaction.customId.startsWith("dailyquiz_option_")
        ) {
            await handleDailyQuizAnswer(interaction);
            return;
        }

        if (
            interaction.customId ===
            "dailyquiz_answer"
        ) {

            await handleDailyQuizButton(
                interaction
            );

            return;
        }

        // ------------------------------------------
        // NORMAL QUIZ
        // ------------------------------------------

        if (
            !interaction.customId.startsWith(
                "quiz_"
            )
        ) {
            return;
        }

        const parts =
            interaction.customId.split(
                "_"
            );

        const quizId =
            parts[1];

        const selectedAnswer =
            Number(parts[2]);

        const quiz =
            activeQuizzes.get(
                quizId
            );

        // ==========================================
        // QUIZ DOESN'T EXIST
        // ==========================================

        if (!quiz) {

            try {

                await interaction.reply({
                    content:
                        "❌ This quiz has ended.",

                    flags:
                        MessageFlags.Ephemeral,
                });

            } catch (error) {

                console.error(
                    "Failed to respond to expired interaction:",
                    error
                );
            }

            return;
        }

        // ==========================================
        // TIMER EXPIRED
        // ==========================================

        if (
            Date.now() >=
            quiz.endsAt
        ) {

            try {

                await interaction.reply({
                    content:
                        "⏱️ **The 20-second timer has ended!**\n\n" +
                        "Please wait for the **rankings and answer reveal**.",

                    flags:
                        MessageFlags.Ephemeral,
                });

            } catch (error) {

                console.error(
                    "Failed to respond to expired timer interaction:",
                    error
                );
            }

            await finishQuiz(
                quizId
            );

            return;
        }

        // ==========================================
        // USER ALREADY ANSWERED
        // ==========================================

        if (
            quiz.answers.has(
                interaction.user.id
            )
        ) {

            try {

                await interaction.reply({
                    content:
                        "⚠️ You have already answered this quiz!",

                    flags:
                        MessageFlags.Ephemeral,
                });

            } catch (error) {

                console.error(
                    "Failed to respond to duplicate answer:",
                    error
                );
            }

            return;
        }
        // ==========================================
        // REDIS QUIZ BAN CHECK
        // ==========================================

        const ban = await isQuizBanned(
            redis,
            interaction.user.id
        );

        if (ban.banned) {
            await interaction.reply({
                embeds: [createQuizBanNoticeEmbed(ban, "quizzes")],
                flags: MessageFlags.Ephemeral,
            });

            return;
        }
        // ==========================================
        // CHECK ANSWER
        // ==========================================

        const isCorrect =
            selectedAnswer ===
            quiz.correctAnswer;

        if (BLOCKED_QUIZ_USERS.has(interaction.user.id)) {
            await interaction.reply({
                content: "🚫 You are not allowed to participate in this quiz.",
                flags: MessageFlags.Ephemeral,
            });



            return;
        }



        quiz.answers.set(
            interaction.user.id,
            {
                selectedAnswer,

                isCorrect,

                userId:
                    interaction.user.id,

                username:
                    interaction.user.username,

                answeredAt:
                    Date.now(),
            }
        );

        const displayName =
            interaction.user.globalName || interaction.user.username;
        const optionEmoji = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"][selectedAnswer] || "🔘";
        const resultEmoji = isCorrect ? "✅" : "❌";
        const resultLabel = isCorrect ? "Correct" : "Incorrect";

        console.log(
            `🌍 [QUIZ #${quiz.questionNumber}] 👤 ${displayName} ➜ ` +
            `${optionEmoji} "${quiz.options[selectedAnswer]}" | ${resultEmoji} ${resultLabel}`
        );

        // ==========================================
        // ANSWER SUBMITTED
        // ==========================================
        // IMPORTANT:
        // We still calculate and store whether the
        // answer is correct above.
        //
        // We simply DO NOT reveal the result to the
        // participant until the quiz finishes.

        try {


            await interaction.reply({
                content:
                    "📝 **Answer submitted!**\n" +
                    "⏳ Wait for the reveal — you'll be **pinged if you're in the Top 5!**",
                flags:
                    MessageFlags.Ephemeral,
            });

        } catch (error) {

            console.error(
                "Failed to send answer submission confirmation:",
                error
            );
        }
    }
});

// ==================================================
// TIMESTAMP UPDATER
// ==================================================

function startTimestampUpdater(
    quizId
) {

    const update = async () => {

        const quiz =
            activeQuizzes.get(
                quizId
            );

        // Quiz already finished
        if (!quiz) {
            return;
        }

        const remaining =
            quiz.endsAt -
            Date.now();

        // Stop updater when time expires
        if (
            remaining <= 0
        ) {
            return;
        }

        const endUnix =
            Math.floor(
                quiz.endsAt / 1000
            );

        try {

            const embed =
                new EmbedBuilder()
                    .setColor(
                        0x5865F2
                    )
                    .setAuthor({
                        name:
                            "🌍 WORLD ADVENTURE CLUB QUIZ",
                    })
                    .setDescription(
                        `### Question No. ${quiz.questionNumber}\n\n` +
                        `### ${quiz.question}\n\n` +
                        `⏱️ **Time Remaining:** <t:${endUnix}:R>`
                    )
                    .setFooter({
                        text:
                            "WAC • World Adventure Club",
                    });

            await quiz.interaction.editReply({
                embeds: [
                    embed,
                ],
            });

        } catch (error) {

            // Don't crash the bot if Discord rejects
            // an old/stale interaction.
            console.error(
                "Timestamp update failed:",
                error.message
            );
        }

        // Update again after 1 second
        setTimeout(
            update,
            1000
        );
    };

    update();
}

// ==================================================
// FINISH QUIZ
// ==================================================

async function finishQuiz(
    quizId
) {

    const quiz =
        activeQuizzes.get(
            quizId
        );

    if (!quiz) {
        return;
    }

    // Remove from active quizzes
    activeQuizzes.delete(
        quizId
    );

    try {

        // ==========================================
        // GET FIRST 5 WINNERS
        // ==========================================

        const winners =
            [
                ...quiz.answers.values(),
            ]
                .filter(
                    answer =>
                        answer.isCorrect
                )
                .sort(
                    (a, b) =>
                        a.answeredAt -
                        b.answeredAt
                )
                .slice(
                    0,
                    MAX_WINNERS
                );

        // ==========================================
        // WINNER TEXT
        // ==========================================

        let winnerText;

        if (
            winners.length ===
            0
        ) {

            winnerText =
                "No one answered correctly.";

        } else {

            winnerText =
                winners
                    .map(
                        (
                            winner,
                            index
                        ) =>
                            `${getMedal(index)} <@${winner.userId}>`
                    )
                    .join("\n");
        }

        // ==========================================
        // DISABLE BUTTONS
        // ==========================================

        const disabledButtons =
            quiz.options.map(
                (
                    option,
                    index
                ) => {

                    return new ButtonBuilder()
                        .setCustomId(
                            `quiz_${quizId}_${index}`
                        )
                        .setLabel(
                            option
                        )
                        .setStyle(
                            index ===
                                quiz.correctAnswer
                                ? ButtonStyle.Success
                                : ButtonStyle.Secondary
                        )
                        .setDisabled(
                            true
                        );
                }
            );

        const disabledRow1 =
            new ActionRowBuilder()
                .addComponents(
                    disabledButtons[0],
                    disabledButtons[1]
                );

        const disabledRow2 =
            new ActionRowBuilder()
                .addComponents(
                    disabledButtons[2],
                    disabledButtons[3]
                );

        // ==========================================
        // UPDATE ORIGINAL QUIZ MESSAGE
        // ==========================================

        await quiz.interaction.editReply({
            components: [
                disabledRow1,
                disabledRow2,
            ],
        });

        // ==========================================
        // OPTION SELECTION COUNTS
        // ==========================================

        const optionCounts = quiz.options.map((option, index) => {
            const count = [...quiz.answers.values()].filter(
                answer => answer.selectedAnswer === index
            ).length;

            return `**${option}** — ${count} ${count === 1 ? "vote" : "votes"}`;
        });

        const totalParticipants = quiz.answers.size;

        // ==========================================
        // RESULTS EMBED
        // ==========================================

        const resultsEmbed =
            new EmbedBuilder()
                .setColor(
                    0x57F287
                )
                .setAuthor({
                    name:
                        "🌍 WORLD ADVENTURE CLUB QUIZ",
                })
                .setTitle(
                    "🏆 QUIZ WINNERS"
                )
                .addFields(

                    {
                        name:
                            "🏆 Winners",

                        value:
                            winnerText,

                        inline:
                            false,
                    },

                    {
                        name:
                            "✅ Correct Answer",

                        value:
                            `**${quiz.options[quiz.correctAnswer]}**`,

                        inline:
                            false,
                    },


                    {
                        name:
                            "📚 Did You Know?",

                        value:
                            quiz.explanation,

                        inline:
                            false,
                    },
                    {
                        name:
                            "👥 **Quiz Participants**",

                        value:
                            ` ${totalParticipants} Users\n`,

                        inline:
                            false,
                    },

                )
                .setFooter({
                    text:
                        "WAC • World Adventure Club",
                });

        // ==========================================
        // SEND RESULTS MESSAGE
        // ==========================================

        await quiz.interaction.followUp({
            content:
                winners.length > 0
                    ? winners
                        .map(winner => `<@${winner.userId}>`)
                        .join(" ")
                    : undefined,
            embeds: [
                resultsEmbed,
            ],
        });

    } catch (error) {

        console.error(
            "Failed to finish quiz:",
            error
        );
    }
}

// ==================================================
// MEDALS
// ==================================================

function getMedal(
    index
) {

    const medals = [
        "🥇",
        "🥈",
        "🥉",
        "4️⃣",
        "5️⃣",
    ];

    return (
        medals[index] ||
        "🏅"
    );
}

// ==================================================
// LOGIN
// ==================================================

async function startBot() {
    await client.login(process.env.DISCORD_TOKEN);

    await initializeWorldPassPools();
    startWorldPassPoolManager();
}

startBot();
